#include "Medico.h"

Medico::Medico()
{
    //ctor
}

Medico::~Medico()
{
    //dtor
}

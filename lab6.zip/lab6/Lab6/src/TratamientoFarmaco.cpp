#include "../include/TratamientoFarmaco.h"

TratamientoFarmaco::TratamientoFarmaco()
{
    // TODO
}

TratamientoFarmaco::~TratamientoFarmaco()
{
    // TODO
}


<vector>Farmaco TratamientoFarmaco::getListaFarmacos()
{
    return this->lFarmacos;
}

TratamientoFarmaco::setListaFarmacos(<vector>Farmaco farmacos)
{
    this->lFarmacos = farmacos;
}


<vector>Farmaco TratamientoFarmaco::getFarmacos()
{
    // TODO
}

TratamientoFarmaco::agregarFarmacoTrat(Farmaco f)
{
    // TODO
}

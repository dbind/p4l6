#include "Administrativo.h"

Administrativo::Administrativo()
{
    //ctor
}

Administrativo::~Administrativo()
{
    //dtor
}

#include "Socio.h"

Socio::Socio()
{
    //ctor
}

Socio::~Socio()
{
    //dtor
}

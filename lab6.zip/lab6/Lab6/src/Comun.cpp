#include "../include/../include/../include/Comun.h"

Comun::Comun()
{
    // TODO
}

Comun::~Comun()
{
    // TODO
}

FechaHora Comun::getFechaReserva()
{
    return this->fechaReserva;
}

Comun::setFechaReserva(FechaHora fecha)
{
    this->fechaReserva = fecha;
}


Comun::agregarFechas(FechaHora fechaConsulta, FechaHora fechaReserva)
{
    // TODO
}

#include "../include/Farmaco.h"

Farmaco::Farmaco()
{
    // TODO
}

Farmaco::~Farmaco()
{
    // TODO
}


string Farmaco::getNombre()
{
    return this->nombre;
}

Farmaco::setNombre(string nombre)
{
    this->nombre = nombre;
}


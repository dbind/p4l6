#include "../include/Tratamiento.h"

Tratamiento::Tratamiento()
{
    // TODO
}

Tratamiento::~Tratamiento()
{
    // TODO
}

string Tratamiento::getDescripcion()
{
    return this->descripcion;
}

Tratamiento::setDescripcion(string descripcion)
{
    this->descripcion = descripcion;
}


DataTratamiento Tratamiento::obtenerDataTratamiento()
{
    // TODO
}

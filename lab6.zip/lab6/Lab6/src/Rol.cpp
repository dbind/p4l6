#include "Rol.h"

Rol::Rol()
{
    //ctor
}

Rol::~Rol()
{
    //dtor
}

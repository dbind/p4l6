#include "../include/Emergencia.h"

Emergencia::Emergencia()
{
    // TODO
}

Emergencia::~Emergencia()
{
    // TODO
}


string Emergencia::getMotivo()
{
    return this->motivo;
}

Emergencia::setMotivo(string motivo)
{
    this->motivo = motivo;
}


Emergencia::agregarFechaMotivo(Fecha fechaConsulta, string motivo)
{
    // TODO
}

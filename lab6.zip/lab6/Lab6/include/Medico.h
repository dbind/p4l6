#ifndef MEDICO_H
#define MEDICO_H


class Medico
{
    public:
        Medico();
        virtual ~Medico();
    protected:
    private:
};

#endif // MEDICO_H

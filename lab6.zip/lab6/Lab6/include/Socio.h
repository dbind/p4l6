#ifndef SOCIO_H
#define SOCIO_H


class Socio
{
    public:
        Socio();
        virtual ~Socio();
    protected:
    private:
};

#endif // SOCIO_H

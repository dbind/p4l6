#ifndef TIPOASIS_H
#define TIPOASIS_H


enum TipoAsis(pendiente, asistio, noAsistio);

#endif // TIPOASIS_H

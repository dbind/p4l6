#ifndef ESTADOUSUARIO_H
#define ESTADOUSUARIO_H


enum EstadoUsuario(adminPorDefecto, normalPrimeraVez, normal);

#endif // ESTADOUSUARIO_H

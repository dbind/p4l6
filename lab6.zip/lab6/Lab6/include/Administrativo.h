#ifndef ADMINISTRATIVO_H
#define ADMINISTRATIVO_H


class Administrativo
{
    public:
        Administrativo();
        virtual ~Administrativo();
    protected:
    private:
};

#endif // ADMINISTRATIVO_H

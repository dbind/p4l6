#ifndef ROL_H
#define ROL_H


class Rol
{
    public:
        Rol();
        virtual ~Rol();
};

#endif // ROL_H

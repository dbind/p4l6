#ifndef FECHA_H
#define FECHA_H


class Fecha
{
    private:
        int dia;
        int mes;
        int anyo;
        int hora;
        int minuto;

    public:
        Fecha(int dia, int mes, int anyo, int hora, int minuto);

        int getDia() { return dia; }
        int getMes() { return mes; }
        int getAnyo() { return anyo; }
        int getHora() { return hora; }
        int getMinuto() { return minuto; }
};

#endif // FECHA_H

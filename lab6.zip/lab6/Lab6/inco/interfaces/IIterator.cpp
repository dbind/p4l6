
#include "IIterator.h"

IIterator::~IIterator(){
    
}
